package GUIDataPasien;
import static GUIDataPasien.koneksi.connect;
import static GUIDataPasien.koneksi.stmt;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
//import com.sun.jdi.connect.spi.Connection;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class datapasien extends javax.swing.JFrame {
  
       
	Statement statBrg;
	Boolean ada = false;
        DefaultTableModel model;
        Pasien ps;
    
    public datapasien() {
        initComponents();
        String []judul = {"Nama","Kartu Identitas","Gender","TTL","Status","Nama Wali","No.Telp","Dokter","Jenis Rawat","Telp Wali"};
        model = new DefaultTableModel(judul,0);
        tbDatapasien.setModel(model);
        hide_nama.setVisible(false);
        ps = new Pasien();
       tampilkan();
    }
     private void tampilkan() {
    int row = tbDatapasien.getRowCount();
    for (int i=0; i<row; i++){
    model.removeRow(0);}

    try {
            
            String sql = "SELECT * FROM data";
            stmt = connect().createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                String data [] = {rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10)};
                model.addRow(data);
            
            
            }
             } catch (Exception e) {
            
            System.out.println("Ambil Data Gagal");
        }  }       

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtNama = new javax.swing.JTextField();
        txtKartu = new javax.swing.JTextField();
        txtTempat = new javax.swing.JTextField();
        txtNoTelp = new javax.swing.JTextField();
        txtNamaWali = new javax.swing.JTextField();
        txtNoTelpWali = new javax.swing.JTextField();
        txtDokter = new javax.swing.JTextField();
        cbJenis = new javax.swing.JComboBox<>();
        cbStatus = new javax.swing.JComboBox<>();
        cbRawat = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbDatapasien = new javax.swing.JTable();
        tbTambah = new javax.swing.JButton();
        tbedit = new javax.swing.JButton();
        tbhapus = new javax.swing.JButton();
        tbkeluar = new javax.swing.JButton();
        hide_nama = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setForeground(new java.awt.Color(153, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel1.setText("DATA PASIEN");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(308, 1, -1, -1));

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setText("Nama");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(113, 22, -1, -1));

        jLabel3.setText("Kartu Identitas");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(113, 50, -1, -1));

        jLabel4.setText("Jenis Kelamin");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(113, 78, -1, -1));

        jLabel5.setText("Tempat, Tanggal Lahir");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(113, 106, -1, -1));

        jLabel6.setText("Status");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(113, 134, -1, -1));

        jLabel7.setText("No Telepon");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(113, 162, 69, -1));

        jLabel8.setText("Nama Wali");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 22, -1, -1));

        jLabel9.setText("Dokter");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 106, -1, -1));

        jLabel10.setText("Jenis Rawat");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 134, -1, -1));

        jLabel11.setText("No Telp Wali");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 50, 69, -1));

        txtNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNamaActionPerformed(evt);
            }
        });
        jPanel2.add(txtNama, new org.netbeans.lib.awtextra.AbsoluteConstraints(247, 19, 140, -1));
        jPanel2.add(txtKartu, new org.netbeans.lib.awtextra.AbsoluteConstraints(247, 47, 140, -1));
        jPanel2.add(txtTempat, new org.netbeans.lib.awtextra.AbsoluteConstraints(247, 103, 140, -1));
        jPanel2.add(txtNoTelp, new org.netbeans.lib.awtextra.AbsoluteConstraints(247, 159, 140, -1));

        txtNamaWali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNamaWaliActionPerformed(evt);
            }
        });
        jPanel2.add(txtNamaWali, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 19, 135, -1));
        jPanel2.add(txtNoTelpWali, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 47, 135, -1));
        jPanel2.add(txtDokter, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 103, 135, -1));

        cbJenis.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Perempuan", "Laki-Laki" }));
        cbJenis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbJenisActionPerformed(evt);
            }
        });
        jPanel2.add(cbJenis, new org.netbeans.lib.awtextra.AbsoluteConstraints(247, 75, 140, -1));

        cbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Menikah", "Belum Menikah" }));
        jPanel2.add(cbStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(247, 131, 140, -1));

        cbRawat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Rawat Inap", "Rawat Jalan" }));
        cbRawat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbRawatActionPerformed(evt);
            }
        });
        jPanel2.add(cbRawat, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 131, 135, -1));

        tbDatapasien.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8", "Title 9", "Title 10"
            }
        ));
        tbDatapasien.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbDatapasienMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbDatapasien);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 277, 766, 119));

        tbTambah.setText("Tambah");
        tbTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbTambahActionPerformed(evt);
            }
        });
        jPanel2.add(tbTambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 210, -1, -1));

        tbedit.setText("Edit");
        tbedit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbeditMouseClicked(evt);
            }
        });
        tbedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbeditActionPerformed(evt);
            }
        });
        jPanel2.add(tbedit, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 210, -1, -1));

        tbhapus.setText("Hapus");
        tbhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbhapusActionPerformed(evt);
            }
        });
        jPanel2.add(tbhapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 210, -1, -1));

        tbkeluar.setText("Keluar");
        tbkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbkeluarActionPerformed(evt);
            }
        });
        jPanel2.add(tbkeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 210, -1, -1));
        jPanel2.add(hide_nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 37, 800, 400));

        jButton1.setText("refresh");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 440));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNamaActionPerformed

    private void cbJenisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbJenisActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbJenisActionPerformed

    private void txtNamaWaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNamaWaliActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNamaWaliActionPerformed

    private void cbRawatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbRawatActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_cbRawatActionPerformed

    private void tbkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbkeluarActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_tbkeluarActionPerformed

    private void tbDatapasienMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbDatapasienMouseClicked
        // TODO add your handling code here:
        int i = tbDatapasien.getSelectedRow();
        if(i>-1){
        txtNama.setText(model.getValueAt(i, 0).toString());
        String nama = model.getValueAt(i,0).toString();
        hide_nama.setText(nama);
        txtKartu.setText(model.getValueAt(i,1).toString());
        txtTempat.setText(model.getValueAt(i,3).toString());
        txtNoTelp.setText(model.getValueAt(i,6).toString());
        txtNamaWali.setText(model.getValueAt(i,5).toString());
        txtNoTelpWali.setText(model.getValueAt(i,9).toString());
        txtDokter.setText(model.getValueAt(i,7).toString());
        }
    }//GEN-LAST:event_tbDatapasienMouseClicked

    private void tbTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbTambahActionPerformed
        // TODO add your handling code here:
           JOptionPane.showMessageDialog(null, "Proses Simpan Data Berhasil");
           String a = txtNama.getText();
           String b = txtKartu.getText();
           String c = cbJenis.getSelectedItem().toString();
           String d = txtTempat.getText();
           String e = cbStatus.getSelectedItem().toString();
           int g = Integer.parseInt(txtNoTelp.getText());
           String f = txtNamaWali.getText();
           String h = txtDokter.getText();
           String i = cbRawat.getSelectedItem().toString();
           int j = Integer.parseInt(txtNoTelpWali.getText());                      
           
           if(ps.tambah_pasien(a, b, c, d, e, f, g, h, i, j)){
           dispose();
           datapasien dp = new datapasien();
           dp.setVisible(true);
           }
    }//GEN-LAST:event_tbTambahActionPerformed

    private void tbeditMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbeditMouseClicked
        try{
           
           
           
        }catch(Exception exc){
            System.err.println(exc.getMessage());}
    }//GEN-LAST:event_tbeditMouseClicked

    private void tbeditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbeditActionPerformed

           String a = txtNama.getText();
           String b = txtKartu.getText();
           String c = cbJenis.getSelectedItem().toString();
           String d = txtTempat.getText();
           String e = cbStatus.getSelectedItem().toString();
           int g = Integer.parseInt(txtNoTelp.getText());
           String f = txtNamaWali.getText();
           String h = txtDokter.getText();
           String i = cbRawat.getSelectedItem().toString();
           int j = Integer.parseInt(txtNoTelpWali.getText());
           String k = hide_nama.getText();

            if(ps.edit_pasien(a,b,c,d,e,f,g,h,i,j,k)){
            dispose();
            datapasien dp = new datapasien();
            
            dp.setVisible(true);
        }  
    }//GEN-LAST:event_tbeditActionPerformed

    private void tbhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbhapusActionPerformed
        // TODO add your handling code here:
         String nama = txtNama.getText();
         if(ps.hapus_pasien(nama)){
                     dispose();
            datapasien gui = new datapasien();
            gui.setVisible(true);
         }
        
    }//GEN-LAST:event_tbhapusActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        dispose();
        datapasien rfr = new datapasien();
        rfr.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new datapasien().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbJenis;
    private javax.swing.JComboBox<String> cbRawat;
    private javax.swing.JComboBox<String> cbStatus;
    private javax.swing.JLabel hide_nama;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbDatapasien;
    private javax.swing.JButton tbTambah;
    private javax.swing.JButton tbedit;
    private javax.swing.JButton tbhapus;
    private javax.swing.JButton tbkeluar;
    private javax.swing.JTextField txtDokter;
    private javax.swing.JTextField txtKartu;
    private javax.swing.JTextField txtNama;
    private javax.swing.JTextField txtNamaWali;
    private javax.swing.JTextField txtNoTelp;
    private javax.swing.JTextField txtNoTelpWali;
    private javax.swing.JTextField txtTempat;
    // End of variables declaration//GEN-END:variables
}
